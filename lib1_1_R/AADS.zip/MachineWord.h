#pragma once

void createMachineWord(char array[], int len, unsigned int& result);
void printMachineWord(unsigned int word);