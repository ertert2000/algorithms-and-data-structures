#pragma once

void processInputBit(const bool bitA[], const bool bitB[], const bool bitC[], const bool bitD[], bool tempABC[]);
void createSet(const char A[], bool bitA[]);