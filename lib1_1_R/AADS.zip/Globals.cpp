#include "Globals.h"

int powerOfSet = 0;