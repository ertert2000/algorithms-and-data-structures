#pragma once
#ifndef NUMBER_GENERATOR_H
#define NUMBER_GENERATOR_H

char* generateNumbers();

#endif