#pragma once
#include <cstring>

void processInput(const char A[4], const char B[4], const char C[4], const char D[4], char E[11], int& sizeOutputArr);