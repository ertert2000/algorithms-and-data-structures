#include <iostream>
#include <ctime>
#include "BST.h"


void printStep(const std::string& name, const BSTListStructure& obj) 
{
    std::cout << name << " Tree:\n";
    obj.printTree();
    std::cout << name << " Sequence: ";
    obj.printSequence();
    std::cout << "---------------------------\n";
}

int main() 
{
    std::srand(std::time(nullptr));

    auto A = BSTListStructure::generate(5, 15);
    auto B = BSTListStructure::generate(5, 15);
    auto C = BSTListStructure::generate(5, 15);
    auto D = BSTListStructure::generate(5, 15);
    auto E = BSTListStructure::generate(5, 15);

    printStep("A", A);
    printStep("B", B);
    printStep("C", C);
    printStep("D", D);
    printStep("E", E);

    auto step1 = BSTListStructure::intersect(B, C);
    printStep("B * C", step1);

    auto step2 = BSTListStructure::unify(D, E);
    printStep("D + E", step2);

    auto step3 = BSTListStructure::concatSeq(step2, A);
    printStep("(D + E) . A", step3);

    auto result = BSTListStructure::unify(step1, step3);
    printStep("Final Result", result);

    return 0;
}