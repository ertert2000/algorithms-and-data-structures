#include "TreeNode.h"

TreeNode::TreeNode(int val) : value(val), left(nullptr), right(nullptr) {}

TreeNode::~TreeNode() {}
