#include "Parallelogram.h"

Parallelogram::Parallelogram(Point sw, Point ne, Point v1, Point v2) : sw(sw), ne(ne), v1(v1), v2(v2), screen(Screen::getInstance()) {}

Point Parallelogram::north() const { return Point(sw.x + v1.x + v2.x, sw.y + v1.y + v2.y); }

Point Parallelogram::south() const { return sw; }

Point Parallelogram::east() const { return Point(ne.x + v1.x, ne.y + v1.y); }

Point Parallelogram::west() const { return Point(sw.x + v2.x, sw.y + v2.y); }

Point Parallelogram::neast() const { return Point(ne.x + v1.x, ne.y + v1.y); }

Point Parallelogram::seast() const { return Point(ne.x, sw.y); }

Point Parallelogram::nwest() const { return sw; }

Point Parallelogram::swest() const { return Point(sw.x + v2.x, sw.y + v2.y); }

void Parallelogram::draw()
{
    screen.put_line(nwest().x, nwest().y, neast().x, neast().y);
    screen.put_line(neast().x, neast().y, seast().x, seast().y);
    screen.put_line(seast().x, seast().y, swest().x, swest().y);
    screen.put_line(swest().x, swest().y, nwest().x, nwest().y);
}

void Parallelogram::move(int dx, int dy)
{
    sw.x += dx;
    sw.y += dy;
    ne.x += dx;
    ne.y += dy;
}

void Parallelogram::resize(double factor)
{
    int dx = ne.x - sw.x;
    int dy = ne.y - sw.y;

    ne.x = sw.x + static_cast<int>(dx * factor);
    ne.y = sw.y + static_cast<int>(dy * factor);
}