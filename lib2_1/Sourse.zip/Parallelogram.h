#pragma once

#include "Shape.h"
#include "Screen.h"

class Parallelogram : public Shape
{
private:
    Point sw, ne;
    Point v1, v2;
    Screen& screen;

public:
    Parallelogram(Point sw, Point ne, Point v1, Point v2) : sw(sw), ne(ne), v1(v1), v2(v2), screen(Screen::getInstance()) {}

    Point north() const override;
    Point south() const override;

    Point east() const override;
    Point west() const override;

    Point neast() const override;
    Point seast() const override;

    Point nwest() const override;
    Point swest() const override;

    void draw() override;

    void move(int dx, int dy) override;

    void resize(double factor) override;
};

